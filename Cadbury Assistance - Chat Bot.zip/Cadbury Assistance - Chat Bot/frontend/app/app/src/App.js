import Chat from "./chatbot/Chat"
function App() {
  return (
    <div className="App">
      <Chat />
    </div>
  );
}

export default App;
